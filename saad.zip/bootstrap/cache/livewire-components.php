<?php return array (
  'backend.cars-table' => 'App\\Http\\Livewire\\Backend\\CarsTable',
  'backend.categories-table' => 'App\\Http\\Livewire\\Backend\\CategoriesTable',
  'backend.modal-table' => 'App\\Http\\Livewire\\Backend\\ModalTable',
  'backend.package-table' => 'App\\Http\\Livewire\\Backend\\PackageTable',
  'backend.plans-table' => 'App\\Http\\Livewire\\Backend\\PlansTable',
  'backend.price-table' => 'App\\Http\\Livewire\\Backend\\PriceTable',
  'backend.roles-table' => 'App\\Http\\Livewire\\Backend\\RolesTable',
  'backend.users-table' => 'App\\Http\\Livewire\\Backend\\UsersTable',
  'frontend.two-factor-authentication' => 'App\\Http\\Livewire\\Frontend\\TwoFactorAuthentication',
);