@extends('template.default')
@section('content')
<div class="main-content">
        <div class="section " style="margin-top:250px">
         {{--  <p>welcome to fitness system</p> --}}

        	
        	
        </div>
@endsection