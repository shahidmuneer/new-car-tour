<footer class="c-footer">
    <div>
        <strong>
            @lang('Copyright') &copy; {{ date('Y') }}
            <x-utils.link href="http://laravel-boilerplate.com" target="_blank" text="SuperCars" />
        </strong>

        @lang('All Rights Reserved')
    </div>

</footer>
